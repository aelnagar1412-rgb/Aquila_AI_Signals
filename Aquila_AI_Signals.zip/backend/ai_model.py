def ai_decision(features):
    base_confidence = (
        features["votes"] * 20 +
        (50 - abs(50 - features["rsi"])) * 0.5
    )
    confidence = min(100, base_confidence)

    if confidence >= 75:
        decision = "BUY" if features["rsi"] < 40 else "SELL"
    else:
        decision = "NO_TRADE"

    return decision, round(confidence, 1)